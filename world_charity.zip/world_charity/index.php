<?php
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>World Charity Portal</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
        display: block;
    }
    </style>

</head>

<body>

    <!-- Navigation -->
<?php include('includes/header.php');?>
<?php include('includes/slider.php');?>
   
    <!-- Page Content -->
    <div class="container">

        <h1 class="my-4">Welcome to World Charity Portal</h1>

        <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <h4 class="card-header">The need for charity</h4>
                   
                        <p class="card-text" style="padding-left:2%">Charity is essential and therefore meant to be done for public benefit, relief and to provide assistance to people at times of need in any part of the world, especially those who are the victims of war, natural disaster, catastrophe, hunger, disease, poverty, orphans by supplying them with food, shelter, medical aid, and other fundamental needs. </p>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <h4 class="card-header">Save Human & Children</h4>
                   
                        <p class="card-text" style="padding-left:2%"> The scale of crisis in the world has increased exponentially in recent years.To help the needy children and women to get their basic rights and help the children in educating them and making them sustainable to face this competitive world in a healthy way. </p>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <h4 class="card-header">Who you could Help</h4>
                   
                        <p class="card-text" style="padding-left:2%">Online is best:Most charities will already have an online platform that they are signed up to for fundraisings like Mydonate or Just GIving.
                        Set up a text option:Someone can simply text a donation amount to a set number and the donation will be taken off their phone bill.
                        Send a direct email out:As soon as you have committed to a charity challenge, send an email out to all your contacts asking them directly to support you and to follow your journey on social media.  </p>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <!-- Portfolio Section -->
        <h2>Some of the Events</h2>

        <div class="row">
                   <?php 
$status=1;
$sql = "SELECT * from tblevents order by rand() limit 6";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>

            <div class="col-lg-4 col-sm-6 portfolio-item">
                <div class="card h-100">
                    <a href="#"><img class="card-img-top img-fluid" src="images/donor.jpg" alt="" ></a>
                    <div class="card-block">
                    <h4 class="card-title"><a href="#"><?php echo htmlentities($result->Event);?></a></h4>
                    <p class="card-text"><b>  Event Description :</b> <?php echo htmlentities($result->EventDescription);?></p>


                    </div>
                </div>
            </div>

            <?php }} ?>
          
 



        </div>
        <!-- /.row -->

        <!-- Features Section -->
        <div class="row">
            <div class="col-lg-6">
                <h2>Events</h2>
          <p> Charity events don’t just raise money for your charity, they also help to engage your supporters and bring publicity to your cause.</p>
                <ul>
                
                
<li>One-Day Online Fundraiser</li>
<li>Seasonal events</li>
<li>Networking dinner</li>
<li>Donation by text drive</li>

                </ul>
                <p>We need community fundraisers! We rely on a network of passionate, creative volunteers to set up events and raise money to support refugees. </p>
            </div>
            <div class="col-lg-6">
                <img class="img-fluid rounded" src="images/donor2.jpg" alt="">
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Call to Action Section -->
        <div class="row mb-4">
            <div class="col-md-8">
            <h4>UNIVERSAL DONORS AND RECIPIENTS</h4>
                <p>
               Give directly transfers cash to households in developing countries via mobile phone-linked payment services. It targets extremely low-income households and people affected by humanitarian crises.</p>
            </div>
            <div class="col-md-4">
                <a class="btn btn-lg btn-secondary btn-block" href="become-donar.php">Become a Donar</a>
            </div>
        </div>

    </div>
    <!-- /.container -->

    <!-- Footer -->
  <?php include('includes/footer.php');?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
