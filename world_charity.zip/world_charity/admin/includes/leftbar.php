	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<!-- <li><a href="#"><i class="fa fa-files-o"></i> Events</a>
<ul>
<li><a href="add-event.php">Add Event</a></li>
<li><a href="manage-event.php">Manage Events</a></li>
</ul>
</li> -->

				<li><a href="manage-event.php"><i class="fa fa-users"></i> Manage Events</a></li>
				<li><a href="add-event.php"><i class="fa fa-users"></i> Add Event</a></li>				
				<li><a href="donor-list.php"><i class="fa fa-users"></i> Donor List</a></li>

				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop""></i> Manage ConatctUs Query</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li><a href="change-password.php"><i class="fa fa-files-o"></i> Change Password</a></li>

			</ul>
		</nav>