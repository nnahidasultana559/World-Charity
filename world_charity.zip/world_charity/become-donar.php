<?php
error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {
$fullname=$_POST['fullname'];
$mobile=$_POST['mobileno'];
$email=$_POST['emailid'];
$cardnumber=$_POST['cardnumber'];
$cardexpirydate=$_POST['cardexpirydate'];
$amount=$_POST['amount'];
$event=$_POST['event'];
$address=$_POST['address'];
$message=$_POST['message'];
$status=1;
$sql="INSERT INTO  tbldonars(FullName,MobileNumber,EmailId,CardNumber,CardExpiryDate,Amount,Event,Address,Message,status) VALUES(:fullname,:mobile,:email,:cardnumber,:cardexpirydate,:amount,:event,:address,:message,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':fullname',$fullname,PDO::PARAM_STR);
$query->bindParam(':mobile',$mobile,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':cardnumber',$cardnumber,PDO::PARAM_STR);
$query->bindParam(':cardexpirydate',$cardexpirydate,PDO::PARAM_STR);
$query->bindParam(':amount',$amount,PDO::PARAM_STR);
$query->bindParam(':event',$event,PDO::PARAM_STR);
$query->bindParam(':address',$address,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Your info submitted successfully";
}
else 
{
$error="Something went wrong. Please try again";
}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>World Charity Portal | Become A Donar</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>

<?php include('includes/header.php');?>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Become a <small>Donor</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Become a Donor</li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="donar" method="post">
<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="font-italic">Full Name<span style="color:red">*</span></div>
        <div><input type="text" name="fullname" class="form-control" required></div>
    </div>
    <div class="col-lg-4 mb-4">
        <div class="font-italic">Mobile Number<span style="color:red">*</span></div>
        <div><input type="text" name="mobileno" class="form-control" pattern="^(?:\+88|88|01)?\d{11}$" title="Mobile number format is not valid" required></div>
    </div>
    <div class="col-lg-4 mb-4">
        <div class="font-italic">Email Id</div>
        <div><input type="email" name="emailid" class="form-control"></div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="font-italic">Card Number<span style="color:red">*</span></div>
        <div><input type="text" name="cardnumber" class="form-control" required pattern=".{16}" pattern="[0-9]+" title="Card Number must be 16 digits"></div>
    </div>


<!-- <div class="row"> -->
    <div class="col-lg-4 mb-4">
        <div class="font-italic">Card Expiration Date<span style="color:red">*</span></div>
        <div><input type="text" name="cardexpirydate" class="form-control" pattern="([0-9]{2}[/]?){2}" minlength="5" title="Card Number expiration date format should be mm/yy" required></div>
    </div>

<!-- <div class="row"> -->
    <div class="col-lg-4 mb-4">
        <div class="font-italic">Donation Amount<span style="color:red">*</span></div>
        <div><input type="number" name="amount" class="form-control" min="50" value="50" step=".01" maxlength="14" title="Minimum amount value should be 50 and Amount can contain two decimal point" required></div>
    </div>
</div>



<div class="row">

<div class="col-lg-4 mb-4">
<div class="font-italic">Events<span style="color:red">*</span> </div>
<div><select name="event" class="form-control" required>
<?php $sql = "SELECT * from  tblevents";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  
<option value="<?php echo htmlentities($result->Event);?>"><?php echo htmlentities($result->Event);?></option>
<?php }} ?>
</select>
</div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Address</div>
<div><textarea class="form-control" name="address"></textarea></div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Message</div>
<div><textarea class="form-control" name="message"> </textarea></div>
</div>
</div>

<div class="row">
<div class="col-lg-4 mb-4">
<div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
</div>



</div>



        <!-- /.row -->
</form>   
        <!-- /.row -->
</div>
  <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    

</body>

</html>
